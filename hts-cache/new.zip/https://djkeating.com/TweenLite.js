<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if IE 9]>			<html class="no-js ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en-US"> <!--<![endif]-->

<head>
    <meta name="msvalidate.01" content="094222B581532A855C6BF7C1CDCE1582" />
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width" />
	<base href="https://djkeating.com/wp-content/themes/push10-keating/"/>
	<title>Page not found - Keating</title>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://djkeating.com/xmlrpc.php"/>
    <link rel="stylesheet" href="https://use.typekit.net/wzt6ncf.css">

    <script>
            var b = document.documentElement;
            b.className = b.className.replace('no-js', 'js');
            b.setAttribute("data-useragent",  navigator.userAgent);
            b.setAttribute("data-platform", navigator.platform );

            function defer(method) {
                // console.log("defer called")
                if (window.jQuery) {
                    method();
                } else {
                    setTimeout(function() { defer(method) }, 50);
                }
            }
    </script>

	
<!-- This site is optimized with the Yoast SEO plugin v11.2.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Keating" />
<meta property="og:site_name" content="Keating" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Keating" />
<meta name="twitter:image" content="https://djkeating.com/wp-content/uploads/2019/01/DJK-About-Us-Diversity.jpg" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://djkeating.com/#organization","name":"Daniel J. Keating Company","url":"https://djkeating.com/","sameAs":["http://linkedin.com/company/djkeating"],"logo":{"@type":"ImageObject","@id":"https://djkeating.com/#logo","url":"https://djkeating.com/wp-content/uploads/2019/11/DJK-Logo-Primary-RGB.png","width":662,"height":464,"caption":"Daniel J. Keating Company"},"image":{"@id":"https://djkeating.com/#logo"}},{"@type":"WebSite","@id":"https://djkeating.com/#website","url":"https://djkeating.com/","name":"Keating","publisher":{"@id":"https://djkeating.com/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://djkeating.com/?s={search_term_string}","query-input":"required name=search_term_string"}}]}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//djkeating.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/djkeating.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel="preload"  href="https://djkeating.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2" onerror="this.rel='stylesheet';"  onload="this.onload=null;this.rel='stylesheet';" as="style">
<link rel="preload"  href="https://djkeating.com/wp-content/themes/push10-keating/assets/dist/snazzy.css?ver=0.1" onerror="this.rel='stylesheet';"  onload="this.onload=null;this.rel='stylesheet';" as="style">
<link rel="preload"  href="https://djkeating.com/wp-content/themes/push10-keating/assets/dist/lightbox.css?ver=0.1" onerror="this.rel='stylesheet';"  onload="this.onload=null;this.rel='stylesheet';" as="style">
<link rel="preload"  href="https://djkeating.com/wp-content/themes/push10-keating/assets/dist/main.min.css?ver=1666694665" onerror="this.rel='stylesheet';"  onload="this.onload=null;this.rel='stylesheet';" as="style">
<script defer src="https://djkeating.com/wp-includes/js/jquery/jquery.js?ver=1.12.4"></script>
<script defer src="https://djkeating.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
<link rel='https://api.w.org/' href='https://djkeating.com/wp-json/' />
<link rel="Shortcut Icon" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/favicon.ico?10/27/22-10:23:14" type="image/x-icon" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-152x152.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-144x144.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-120x120.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-114x114.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-76x76.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-72x72.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon-57x57.png?10/27/22-10:23:14" />
<link rel="apple-touch-icon-precomposed" href="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/favicon/apple-touch-icon.png?10/27/22-10:23:14" />
    


            <style>
        .about-banner{
            background-image:url();
            height:809px;
        }
        .team-banner{
        background-image:url();
        /*height:650px;*/
        }
        .team-member-banner{
            /*height:926px;*/
            background-image:url();
        }
        .standard-banner, .img-banner{
            background-image:url();
            /*height:650px;*/
        }
        @media(max-width:766px){
            .team-member-banner{
                /*height:926px;*/
                background-image:url();
            }
        }
        .img-banner{
            background-image:url();
            mix-blend-mode: multiply;
        }
        .contact-banner{
                background-image:url('');

        }
        .page-404{
            background-image:url('https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/404-page.jpg');
            height:880px;
            position: relative;
        }
        .page-404:after{
            opacity: 0.96;
            background-image: linear-gradient(-90deg, #1C233C 0%, #3C5A74 100%);
            content: "";
            position: absolute;
            top:0px;
            left:0px;
            width:100%;
            height:100%;
        }
        .page-404:before{
            opacity: 0.04;
            font-family: "PlayfairDisplay-Regular";
            font-size: 800px;
            color: #FFFFFF;
            letter-spacing: 0;
            text-align: center;
            line-height: 1000px;
            content:"404";
            position: absolute;
            /*top:50%;*/
            left: 50%;
            bottom:70px;
            transform:translate(-50%, 0%);
            z-index:3;
        }
    </style>

    <script>
        // `rel=preload` Polyfill for <link> elements
        var DOMTokenListSupports = function (tokenList, token) {
            if (!tokenList || !tokenList.supports) {
                return;
            }
            try {
                return tokenList.supports(token);
            }
            catch (e) {
                if (e instanceof TypeError) {
                    console.log("The DOMTokenList doesn't have a supported tokens list");
                }
                else {
                    console.error("That shouldn't have happened");
                }
            }
        };
        var linkSupportsPreload = DOMTokenListSupports(document.createElement('link').relList, 'preload');
        if (!linkSupportsPreload) {
            // Dynamically load the things that relied on preload.
            var links = document.getElementsByTagName('link');
            for (var i = 0; i < links.length; i++) {
                var link = links[i];
                // qualify links to those with rel=preload and as=style attrs
                if (link.rel === 'preload' && link.getAttribute('as') === 'style') {
                    // prevent re-running on link
                    link.setAttribute('rel', 'stylesheet');
                }
            }
        }
    </script>

    <style>
        #ie-unsupported{
            display: none;
        }
        html[data-useragent*='MSIE 10.0'] #ie-unsupported {
          display: block;
        }
        html[data-useragent*='MSIE 10.0'] #site {
          display: none;
        }
        .ie9 #ie-unsupported{
                display: block;
            }
        .lt-ie9 #ie-unsupported{
                display: block;
            }
        .lt-ie9 #site{
                display: none;
            }
        .ie9 #site{
                display: none;
            }

    </style>


<!-- Global site tag (gtag.js) - Google Analytics -->

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-139839973-1"></script>

    <script>

    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'UA-139839973-1');

    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-140002222-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-140002222-1');
    </script>

</head>

<body class="error404 interior-page" style = "opacity:0; transition: 0.5s" >

    <div id = "ie-unsupported" style = "position:fixed;
    margin:0 auto;
    margin-top:400px;
     text-align:center;
     width:100%;
 ">
           <img width = "200px" style = "margin:0 auto; margin-bottom:40px;" alt = "Resource Logo" src = "https://djkeating.com/wp-content/themes/push10-keating/../../login-logo.png">
    <p style = "max-width:300px; margin:0 auto;">Hello, you are using an old browser that's unsafe and no longer supported. Please consider <a href = "https://support.microsoft.com/en-us/help/17621/internet-explorer-downloads">updating</a> your browser to a newer version, or downloading a <a href="https://www.google.com/chrome/browser/desktop/index.html">modern</a> browser.</p>
    </div>


    </div>


    <div id="site" >

        <header>
            <div class="frame">

                <div id="logo">
                    <a href="/" id="logo-link">
                        <img src="https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/logo.svg" alt="Daniel J Keating" />
                    </a>
                </div>
                <div class = "toggle-container">
                <div id = "menu-toggle">
                    
                </div>
            </div>
                <div class="main-nav">
                    <ul class = "container">
                    <li id="menu-item-240" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-240"><a href="https://djkeating.com/about-us/">About Us</a></li>
<li id="menu-item-243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="https://djkeating.com/leadership/">Leadership</a></li>
<li id="menu-item-242" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-242"><a href="https://djkeating.com/portfolio/">Portfolio</a></li>
<li id="menu-item-238" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-238"><a href="https://djkeating.com/services/">Services</a></li>
<li id="menu-item-241" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-241"><a href="https://djkeating.com/contact/">Contact</a></li>
                    <li>
                        <ul class = "secondary-menu anim-bar init">
                        <li id="menu-item-245" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-245"><a href="https://djkeating.com/careers/">Careers</a></li>
<li id="menu-item-244" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-244"><a href="https://djkeating.com/for-subcontractors/">For Subcontractors</a></li>
<li id="menu-item-246" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-246"><a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/company/daniel-j.-keating-company">LinkedIn</a></li>
                        </ul>
                    </li>
                </ul>
                </div>

            </div>
        </header>
    <main id="main-content">
    	<style>

    	.page-404{
    		background-image:url('https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/404-page.jpg');
    		height:880px;
    		position: relative;
    	}
    	.page-404:after{
    		opacity: 0.96;
			background-image: linear-gradient(-90deg, #1C233C 0%, #3C5A74 100%);
			content: "";
			position: absolute;
			top:0px;
			left:0px;
			width:100%;
			height:100%;
    	}
    	.page-404:before{
	    	opacity: 0.04;
			font-family: "PlayfairDisplay-Regular";
			font-size: 800px;
			color: #FFFFFF;
			letter-spacing: 0;
			text-align: center;
			line-height: 1000px;
			content:"404";
			position: absolute;
			/*top:50%;*/
			left: 50%;
			bottom:70px;
			transform:translate(-50%, 0%);
			z-index:3;
		}
    </style>
       <section class = "page-404">
       	<div class = "container">
		<h1 class = "anim-bar">Page Not Found</h1>
		       		<a class = "link" href = "/">Back To Home</a>

		</div>


       </section>
    </main>

            <footer>


            	<div class = "locations">


            		            			            				<div class = "location-item">
            					<div class = "location-name">
            						<a target = "_blank" href = "https://www.google.com/maps/dir/?api=1&destination=134+N+Narberth+Ave%0ANarberth%2C+PA+19072">
                                                      Narberth Office                                                </a>
            					</div>
            					<div class = "location-address">
            						<p class="p1">134 N Narberth Ave</p>
<p class="p1">Narberth, PA 19072</p>
            					</div>
            				</div>
            			            				<div class = "location-item">
            					<div class = "location-name">
            						<a target = "_blank" href = "https://www.google.com/maps/dir/?api=1&destination=123+South+Broad+Street%2C+Suite+2230%0APhiladelphia%2C+PA+19109">
                                                      Center City Office                                                </a>
            					</div>
            					<div class = "location-address">
            						<p class="p1">123 South Broad Street, Suite 2230</p>
<p class="p1">Philadelphia, PA 19109</p>
            					</div>
            				</div>
            			            		


            	</div>


            	<div class = "copyright">
            		<div class = "footer-menu">
            		            				<a href = "https://djkeating.com/about-us/">About Us</a>
            		            				<a href = "https://djkeating.com/portfolio/">Portfolio</a>
            		            				<a href = "https://djkeating.com/contact/">Contact</a>
            		            	</div>

            		<div class = "right-align">

            			<a target = "_blank" href = "https://www.linkedin.com/company/daniel-j.-keating-company">
            	<img alt = "Linked In" src = "https://djkeating.com/wp-content/themes/push10-keating/assets/imgs/linkedin.svg">
            			</a>
            			<div class = "copyright-info">
            				©2022 Daniel J. Keating Company.<br>
							All Rights Reserved. <a href = "https://push10.com" target = "_blank">Web Design by Push10 Branding Agency.</a>

            			</div>


            		</div>


            	</div>





            </footer>

        </div><!-- close #site -->


        <script type='text/javascript'>
/* <![CDATA[ */
var myajax = {"ajaxurl":"https:\/\/djkeating.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script defer src="https://djkeating.com/wp-content/themes/push10-keating/assets/dist/javascript.min.js?ver=1666694665"></script>
<script defer src="https://djkeating.com/wp-includes/js/wp-embed.min.js?ver=5.2"></script>

    </body>

</html>
